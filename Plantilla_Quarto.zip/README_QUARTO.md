# Plantilla TFG GIS UBU – Quarto

> Plantilla Quarto para la **Memoria** y la **Documentación Técnica (Anexos)** del
> Trabajo Fin de Grado · Grado en Ingeniería de la Salud · Universidad de Burgos.

---

## ¿Por dónde empiezo?

Si acabas de descargar esta plantilla, sigue estos tres pasos:

1. **Instala los requisitos** (ver sección más abajo).
2. **Pon tus datos personales** en `preambulo_memoria.tex` y `preambulo_anexos.tex`.
3. **Pulsa Render** en RStudio o Positron sobre `memoria.qmd` o `anexos.qmd`.

---

## Estructura de archivos

```
tfg_ubu_quarto/
├── memoria.qmd              ← Escribe aquí el contenido de tu memoria
├── anexos.qmd               ← Escribe aquí el contenido de tus anexos
├── preambulo_memoria.tex    ← PON AQUÍ TU NOMBRE, TUTORES Y TÍTULO (memoria)
├── preambulo_anexos.tex     ← PON AQUÍ TU NOMBRE, TUTORES Y TÍTULO (anexos)
├── bibliografia.bib         ← Tus referencias bibliográficas (memoria)
├── bibliografiaAnexos.bib   ← Tus referencias bibliográficas (anexos)
├── img/
│   ├── CabeceraEPS.png      ← Cabecera UBU-EPS (no tocar)
│   └── Logo_GIS.png         ← Logo Ingeniería de la Salud (no tocar)
└── README_QUARTO.md         ← Este archivo
```

---

## Paso 1 — Pon tus datos personales

Abre **`preambulo_memoria.tex`** y busca el bloque señalado con el comentario
`EDITAR ESTOS DATOS`. Cambia los valores por los tuyos:

```latex
% ── EDITAR ESTOS DATOS ──────────────────────────────────────
\newcommand{\nombre}{María García López}          % Tu nombre completo
\newcommand{\nombreTutor}{Juan Pérez Martínez}    % Nombre del tutor/a 1
\newcommand{\nombreTutorb}{Ana Sánchez Ruiz}      % Nombre del tutor/a 2
\newcommand{\dni}{12345678A}                      % Tu DNI
% ────────────────────────────────────────────────────────────
```

Después abre el **primer bloque `{=latex}`** de `memoria.qmd` y cambia el título:

```latex
\title{Detección automática de arritmias mediante aprendizaje profundo}
```

Repite exactamente lo mismo en **`preambulo_anexos.tex`** y en `anexos.qmd`.

> ⚠️ Si solo tienes **un tutor**, comenta la línea `\tutorb` en el preámbulo y
> en la portada cambia `Tutores:` por `Tutor:` en la línea correspondiente.

---

## Paso 2 — Instala los requisitos

| Software | Versión mínima | Dónde descargarlo |
|----------|---------------|-------------------|
| R | ≥ 4.3 | [cran.r-project.org](https://cran.r-project.org) |
| Quarto | ≥ 1.4 | [quarto.org/docs/download](https://quarto.org/docs/download/) |
| RStudio o Positron | reciente | [posit.co](https://posit.co/downloads/) |
| TeX Live o MiKTeX | completo | [tug.org/texlive](https://tug.org/texlive/) |

Instala también los paquetes de R necesarios ejecutando esto en la consola de R:

```r
install.packages(c("knitr", "dplyr", "ggplot2", "tidyr"))
```

> ⚠️ Necesitas una instalación **completa** de TeX Live o MiKTeX, no la versión
> mínima. La clase `memoir` y paquetes como `booktabs`, `microtype` o `lmodern`
> deben estar disponibles.

---

## Paso 3 — Compila el PDF

Abre `memoria.qmd` en RStudio o Positron y pulsa el botón **Render** (barra
superior del editor). Se generará `memoria.pdf` en la misma carpeta.

Para los anexos, haz lo mismo con `anexos.qmd` → genera `anexos.pdf`.

También puedes compilar desde la terminal integrada:

```bash
quarto render memoria.qmd
quarto render anexos.qmd
```

---

## Cómo escribir tu TFG

### Texto normal
Escribe en Markdown directamente después de cada bloque `{=latex}` que marca
el inicio de un capítulo. Por ejemplo:

```markdown
```{=latex}
\capitulo{2}{Objetivos}
```

En este apartado se definen los **objetivos** del trabajo...

## Objetivo general

Desarrollar un sistema capaz de...
```

### Citar bibliografía
Añade tus referencias en `bibliografia.bib` y cítalas en el texto con:

```markdown
Como señalan [@bortolot2005], los métodos basados en LiDAR...
```

El estilo de cita es **APA** (autor, año) y la bibliografía se genera
automáticamente al final del documento.

### Incluir una tabla generada con R

```r
#| label: tbl-mi-tabla
#| tbl-cap: "Descripción de la tabla"

library(knitr)
mi_datos |>
  kable(booktabs = TRUE, format = "latex")
```

### Incluir una figura generada con R

```r
#| label: fig-mi-figura
#| fig-cap: "Descripción de la figura"

library(ggplot2)
ggplot(mis_datos, aes(x = variable1, y = variable2)) +
  geom_point() +
  theme_minimal()
```

### Mostrar u ocultar el código R en el PDF
- El código es **visible por defecto** en esta plantilla (`echo: true`).
- Para ocultar el código de un chunk concreto añade `#| echo: false` al inicio.
- Para ocultar el código de todo el documento, cambia `echo: true` a
  `echo: false` en la sección `knitr > opts_chunk` del YAML.

### Incluir una imagen clásica (no generada con R)
Coloca la imagen en la carpeta `img/` y usa:

```latex
```{=latex}
\imagen{img/mi_esquema.png}{Descripción de la imagen}{0.8}
```
```

El tercer parámetro (`0.8`) es la escala relativa al ancho de página (entre 0 y 1).

### Añadir un nuevo apéndice en `anexos.qmd`

```markdown
```{=latex}
\apendice{Nombre del nuevo apéndice}
```

Contenido del apéndice en Markdown...
```

---

## Preguntas frecuentes

**¿Por qué el `title:` del YAML está como `" "` (espacio en blanco)?**
Para evitar que Quarto genere una portada automática que se solaparía con la
portada personalizada de la UBU. El título real del TFG se pone dentro del
bloque `{=latex}` al inicio del documento.

**¿Por qué hay archivos `.tex` además de los `.qmd`?**
La portada, los índices y los estilos de la plantilla UBU requieren comandos
LaTeX avanzados que no se pueden configurar solo desde el YAML de Quarto. Los
preámbulos `.tex` contienen toda esa lógica y se cargan automáticamente al
compilar.

**¿Puedo usar esta plantilla en VSCode?**
Sí, instalando la extensión oficial de Quarto para VSCode. El flujo de trabajo
es idéntico al de RStudio/Positron.

**El PDF sale con errores de paquetes LaTeX que no encuentra.**
Asegúrate de tener TeX Live o MiKTeX en versión **completa**. Si usas TeX Live
puedes instalar paquetes concretos con:
```bash
tlmgr install memoir booktabs microtype lmodern
```

---

## Notas técnicas (para usuarios avanzados)

- Se usa la clase **`memoir`** con estilo de capítulos `bianchi`, igual que la
  plantilla LaTeX original de la UBU.
- Los comandos `\capitulo{}{}` y `\apendice{}{}` están definidos en los
  preámbulos `.tex` y se invocan desde bloques `{=latex}`.
- Motor de compilación: **pdflatex**. Si necesitas soporte Unicode avanzado
  (fuentes especiales, caracteres no latinos), cambia en el YAML:
  `pdf-engine: xelatex`.
- Los índices (TOC, LOF, LOT) se gestionan manualmente desde un bloque
  `{=latex}` para mantener el orden correcto con la clase `memoir`.
